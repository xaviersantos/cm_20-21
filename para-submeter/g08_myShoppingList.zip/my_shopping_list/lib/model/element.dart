class ElementItem{
  final String name;
  final bool isDone;

  ElementItem(this.name, this.isDone);

}