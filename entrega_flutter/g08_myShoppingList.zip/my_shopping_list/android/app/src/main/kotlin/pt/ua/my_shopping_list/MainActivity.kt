package pt.ua.my_shopping_list

import io.flutter.embedding.android.FlutterActivity;

class MainActivity(): FlutterActivity() {
}
